﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace example1
{
    public partial class Form1 : Form
    {
        List<Button> buttons;
        bool blackIsClicked = false;
        public Form1()
        {
            buttons = new List<Button>();
            for (int i = 1; i <= 3; i ++)
            {
                for (int j = 1; j <= 3; ++ j)
                {
                    Button b = new Button();
                    b.Location = new Point(i * 100, j * 100);
                    b.Click += click;
                    b.Text = "" + (i * 3 + j - 1);
                    b.Size = new Size(100, 100);
                    buttons.Add(b);
                    Controls.Add(b);
                }
            }
            InitializeComponent();
        }

        private void click(object sender, EventArgs e)
        {
            Button b = sender as Button;
            if (b.Text == "7")
            {
                foreach (Button button in buttons)
                {
                    if (button.Text == "4" || button.Text == "6" || button.Text == "8" || button.Text == "10")
                    {
                        if (blackIsClicked == false) {
                            button.BackColor = Color.Black;
                        }
                        else
                        {
                            button.BackColor = Color.White;
                        }
                        
                    }
                }
                if (blackIsClicked == false)
                    blackIsClicked = true;
                else
                    blackIsClicked = false;
            }
        }
    }
}
