﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SampleYelibay1
{
    public partial class Form1 : Form
    {
        List<Button> buttons;
        Color[] colors = {Color.Red, Color.Wheat,
            Color.Gray, Color.Black, Color.White, Color.Yellow };

        public Form1()
        {
            InitializeComponent();
            buttons = new List<Button>();
            for (int i = 1; i <= 3; i ++)
            {
                for (int j = 1; j <= 3; ++ j)
                {
                    Button b = new Button();
                    b.Location = new Point(i * 30, j * 30);
                    b.Size = new Size(30, 30);
                    b.Click += click;
                    b.Text = (i * j).ToString();
                    buttons.Add(b);
                    Controls.Add(b);
                }
            }
        }
        private void click(object sender, EventArgs e)
        {
            Button b = sender as Button;
            int idx = int.Parse(b.Text);
            //MessageBox.Show(b.Text);
            for (int i = 0; i < 9; ++i)
            {
                buttons[i].BackColor = colors[idx];
            }
            textBox1.Text += colors[idx].Name;
        }


    }
}
