﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SampleYelibay2
{
    public partial class Form1 : Form
    {
        Bitmap bitmap;
        Graphics graphics;
        Rectangle r;
        int dir = -1;
        int b = 0;
        public Form1()
        {
            InitializeComponent();
            r = new Rectangle(30, 30, 30, 30);
            bitmap = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            graphics = Graphics.FromImage(bitmap);
            graphics.Clear(Color.White);
            pictureBox1.Image = bitmap;
           // graphics.FillEllipse(Brushes.Red, r);
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (b == 0)
            {
                return;
            }
            if (b == 1)
            {
                int x = int.Parse(textBox1.Text);
                int y = int.Parse(textBox2.Text);
                r = new Rectangle(x, y, 30, 30);
                b = 2;
            }
            if (dir == 0)
            {
                r.Y += 5;
            }
            if (dir == 1)
            {
                r.Y -= 5;
            }
            if (dir == 2)
            {
                r.X += 5;
            }
            if (dir == 3)
            {
                r.X -= 5;
            }
            graphics.Clear(Color.White);
            //graphics.Clear();
            graphics.FillEllipse(Brushes.Red, r);
            pictureBox1.Refresh();
        }

        private void up_Click(object sender, EventArgs e)
        {
            dir = 1;
            if (b == 0)
            {
                b = 1;
            }
        }

        private void right_Click(object sender, EventArgs e)
        {
            dir = 2;
            if (b == 0)
            {
                b = 1;
            }
        }

        private void down_Click(object sender, EventArgs e)
        {
            dir = 0;
            if (b == 0)
            {
                b = 1;
            }
        }

        private void left_Click(object sender, EventArgs e)
        {
            dir = 3;
            if (b == 0)
            {
                b = 1;
            }
        }
    }
}
