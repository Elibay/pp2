﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AigerimExm1
{
    public partial class Form1 : Form
    {
        int x, y;
        int func1 = 0;
        public Form1()
        {
            InitializeComponent();
            for (int i = 1; i <= 3; i++)
            {
                for (int j = 1; j <= 3; ++j)
                {
                    Button b = new Button();
                    b.Location = new Point(i * 100, j * 100);
                    b.Click += digit;
                    b.Text = "" + ((i- 1) * 3 + j);
                    b.Size = new Size(100, 100);
                    //buttons.Add(b);
                    Controls.Add(b);
                }
            }
            Button b1 = new Button();
            b1.Location = new Point(400, 100);
            b1.Click += func;
            b1.Text = "+";
            b1.Size = new Size(100, 100);
            //buttons.Add(b);
            Controls.Add(b1);
            Button b2 = new Button();
            b2.Location = new Point(400, 200);
            b2.Click += func;
            b2.Text = "=";
            b2.Size = new Size(100, 100);
            //buttons.Add(b);
            Controls.Add(b2);

            Button b3 = new Button();
            b3.Location = new Point(400, 300);
            b3.Click += func;
            b3.Text = "A";
            b3.Size = new Size(100, 100);
            //buttons.Add(b);
            Controls.Add(b3);

            Button b4 = new Button();
            b4.Location = new Point(500, 100);
            b4.Click += func;
            b4.Text = "S";
            b4.Size = new Size(100, 100);
            //buttons.Add(b);
            Controls.Add(b4);

            Button b5 = new Button();
            b5.Location = new Point(500, 200);
            b5.Click += func;
            b5.Text = "G";
            b5.Size = new Size(100, 100);
            //buttons.Add(b);
            Controls.Add(b5);

            Button b6 = new Button();
            b6.Location = new Point(500, 300);
            b6.Click += func;
            b6.Text = "P";
            b6.Size = new Size(100, 100);
            //buttons.Add(b);
            Controls.Add(b6);

        }
        private void digit(object sender, EventArgs e)
        {
            Button button = sender as Button;
            textBox1.Text += button.Text;

        }
        bool isPrime(int x)
        {
            if (x == 1)
            {
                return false;
            }
            for (int i = 2; i * i <= x; ++ i)
            {
                if (x % i == 0)
                {
                    return false;
                }
            }
            return true;
        }
        private void func(object sender, EventArgs e)
        {
            Button button = sender as Button;
            try
            {
                if (button.Text == "+")
                {
                    x += int.Parse(textBox1.Text);
                    textBox1.Text = "";
                    func1 = 1;
                }
                else if (button.Text == "=")
                {
                    y = int.Parse(textBox1.Text);
                    if (func1 == 1)
                    {
                        textBox1.Text = "" + (x + y);
                    }
                    else if (func1 == 2)
                    {
                        int a = (x / y);
                        int b = (a + 1) * y;
                        int c = (a - 1) * y;

                        a = a * y;
                        int d1 = Math.Abs(a - x);
                        int d2 = Math.Abs(b - x);
                        int d3 = Math.Abs(c - x);
                        int mini = Math.Min(d1, d2);
                        mini = Math.Min(d3, mini);
                        if (d1 == mini)
                        {
                            textBox1.Text = "" + a;
                        }
                        else if (d2 == mini)
                        {
                            textBox1.Text = "" + b;
                        }
                        else
                        {
                            textBox1.Text = "" + c;
                        }
                        //MessageBox.Show(a + " " + b + " " + c);
                    }
                    else if (func1 == 3)
                    {
                        int z = 0;
                        for (int i = 1; i <= x; ++i)
                        {
                            if (x % i == 0 && y % i == 0)
                            {
                                z = i;
                            }
                        }

                        textBox1.Text = "" + z;
                    }
                    else if (func1 == 4)
                    {
                        int sum = 0;
                        for (int i = x; i <= y; i ++)
                        {
                            if (isPrime(i) == true)
                            {
                                sum += i;
                            }
                        }
                        textBox1.Text = "" + sum;
                    }
                }
                else if (button.Text == "A")
                {
                    textBox1.Text = "";
                    func1 = 0;
                }
                else if (button.Text == "S")
                {
                    x = int.Parse(textBox1.Text);
                    func1 = 2;
                    textBox1.Text = "";

                }
                else if (button.Text == "G")
                {
                    x = int.Parse(textBox1.Text);
                    func1 = 3;
                    textBox1.Text = "";

                }
                else if (button.Text == "P")
                {
                    x = int.Parse(textBox1.Text);
                    func1 = 4;
                    textBox1.Text = "";

                }
            }
            catch {
                MessageBox.Show("Error");
            }


        }

    }
}
