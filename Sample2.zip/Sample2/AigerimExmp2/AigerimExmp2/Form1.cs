﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AigerimExmp2
{
    public partial class Form1 : Form
    {
        Bitmap bmp;
        Graphics gbmp;
        Rectangle golova = new Rectangle(30, 200, 30, 30);
        Rectangle telo = new Rectangle(45, 220, 3, 30);
        Point leftRukax = new Point(45, 220);
        Point leftRukay = new Point(30, 240);
        Point rightRukax = new Point(45, 220);
        Point rightRukay = new Point(60, 240);
        Point leftNogax = new Point(45, 250);
        Point leftNogay = new Point(35, 270);

        Point rightNogax = new Point(45, 250);
        Point rightNogay = new Point(60, 270);

        public Form1()
        {
            InitializeComponent();
            bmp = new Bitmap(@"123.png");
            bmp = new Bitmap(bmp, new Size(pictureBox1.Width, pictureBox1.Height));
            pictureBox1.Image = bmp;
            gbmp = Graphics.FromImage(bmp);
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //Bitmap bmp2 = new Bitmap();
            gbmp.Clear(Color.White);
            Image img = Image.FromFile(@"123.png");
            img = new Bitmap(img, new Size(pictureBox1.Width, pictureBox1.Height));
            gbmp.DrawImage(img, 0, 0);
            gbmp.FillEllipse(Brushes.Black, golova);
            gbmp.FillRectangle(Brushes.Red, telo);
            gbmp.DrawLine(new Pen(Color.Black, 4), leftRukay, leftRukax);
            gbmp.DrawLine(new Pen(Color.Black, 4), rightRukay, rightRukax);
            gbmp.DrawLine(new Pen(Color.Blue, 4), leftNogay, leftNogax);
            gbmp.DrawLine(new Pen(Color.Blue, 4), rightNogay, rightNogax);
           
            pictureBox1.Refresh();
            golova.X += 10;

            leftNogax.X += 10;
            leftNogay.X += 10;

            rightNogax.X += 10;
            rightNogay.X += 10;

            leftRukay.X += 10;
            leftRukax.X += 10;

            rightRukay.X += 10;
            rightRukax.X += 10;
            if (telo.X <= 500)
                b = 1;
        }
    }
}
